#include <iostream>
#include <fstream>
#include <string>

std::wstring utf8_to_utf16 (std::string str);

std::string utf16_to_utf8 (std::wstring str);